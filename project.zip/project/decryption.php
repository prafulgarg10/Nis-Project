<!DOCTYPE html>
<html>
	<head>
	<title>Secure Military Communication Portal</title>
	<link rel="stylesheet" href="libs/style.css">
    </head>
	<body>
			<h1 style="text-align:center;font-size:48px;background-color: rgb(255,255,255,0.5);"><strong>Decrypt the message</strong></h1>
			<div class="form">
				<h3>Paste the Cipher here</h3>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >
                <div class="form-group">
						<label>ID</label>
						<input type="text" class="form-control" name="id" style="height: 30px;" value="<?php echo @$id; ?>" required pattern="[a-zA-Z0-9]+" placeholder="Enter id"/>
					</div>
				    <div class="form-group">
						<label>Cipher</label>
						<textarea rows="15" cols="30" type="text" class="form-control" name="cipher" value="<?php echo @$body; ?>" required placeholder="Cipher"></textarea>
					</div>
                    <div class="form-group">
						<input type="submit" name="submit" class="btn" value="Generate"/>
					</div>
				</form>
                <div class="form-group">
                    <label>Message</label>
                    <div style="width:65%;float:left;font-size:20px;">
                    <?php
                      if(isset($_POST['submit']) ) {
                       $encryption_key = $_POST['id']; 
                       $hashedCipherText = $_POST['cipher'];
					   $cipherText = substr($hashedCipherText, 0, 108);
					   $hash = substr($hashedCipherText, 108);
                       $cipher = "aes-256-cbc";
					   $iv = "�DT�� ��y'?�W";
					   $iv1 = "]>��Pc������m";
                       $decrypted_data = openssl_decrypt($cipherText, $cipher, $encryption_key, 0, $iv1); 
                       $decrypted_data_second = openssl_decrypt($decrypted_data, $cipher, $encryption_key, 0, $iv); 
					   $hashed = hash('sha512', $cipherText);
					   if($hash==$hashed){
						   if($decrypted_data_second==null){
							   echo "Wrong key used";
						   }
						   echo $decrypted_data_second;
					   }
					   else{
						   echo "Some lo in between";
					   }
                     }
                    ?>
                    </div>
                    </div>
                </div>
			</div>
			
		 <div style="height:20px";>

		 </div>
	</body>

</html>