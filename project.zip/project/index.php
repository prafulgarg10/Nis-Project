<?php

include('libs/phpqrcode/qrlib.php'); 

if(isset($_POST['submit']) ) {
	$tempDir = 'temp/'; 
	$id = $_POST['id'];
	$filename = "message" . $id;
	$Message =  $_POST['msg'];
	//Define cipher 
    $cipher = "aes-256-cbc"; 
    $encryption_key = $id; 
    $iv = "�DT�� ��y'?�W";
	$iv1 = "]>��Pc������m";
    $msg = openssl_encrypt($Message, $cipher, $encryption_key, 0, $iv);
    $msg_second = openssl_encrypt($msg, $cipher, $encryption_key, 0, $iv1);
	// echo $msg . "<br></br>";
	// echo $msg_second . "<br></br>";
	$hashed = hash('sha512', $msg_second);
	$hashed_msg = $msg_second . $hashed;
	echo $hashed_msg;
	QRcode::png($hashed_msg, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
}
?>
<!DOCTYPE html>
<html>
	<head>
	<title>Secure Military Communication Portal</title>
	<link rel="stylesheet" href="libs/style.css">
    </head>
	<body>
			<h1 style="text-align:center;font-size:48px;background-color: rgb(255,255,255,0.5);"><strong>QR code based double encryption for Communication</strong></h1>
			<div class="form">
				<h3>Enter the secret message</h3>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >
				    <div class="form-group">
						<label>ID</label>
						<input type="text" class="form-control" name="id" style="height: 30px;" value="<?php echo @$id; ?>" required pattern="[a-zA-Z0-9]+" placeholder="Enter id"/>
					</div>
				    <div class="form-group">
						<label>Message</label>
						<textarea rows="15" cols="30" type="text" class="form-control" name="msg" value="<?php echo @$body; ?>" required pattern="[a-zA-Z0-9 .]+" placeholder="Enter your message"></textarea>
					</div>
					<div class="form-group">
						<input type="submit" name="submit" class="btn" />
					</div>
				</form>
			</div>
			<?php
			if(!isset($filename)){
				$filename = "TechSu";
			}
			?>
			<div class="qr">
			<h2 style="text-align:center;">Secret Message: </h2>
			<div class="qr-field">
					<div class="qrframe">
							<?php echo '<img src="temp/'. @$filename.'.png" style="width:200px; height:200px;"><br>'; ?>
					</div>
			</div>
			<div class="qr-field">
			<div>
			<a href="download.php?file=<?php echo $filename; ?>.png ">Get QR for sharing</a>
		    </div>
		   </div>
		</div>
		 <div style="height:20px";>

		 </div>
	</body>

</html>